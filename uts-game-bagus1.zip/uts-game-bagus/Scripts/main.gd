class_name Main
extends Node2D

## Simple HUD: how many fruits the player has picked up.
@onready var score_label: Label = $HUD/ScoreLabel

var _collected: int = 0
var _total: int = 0


func _ready() -> void:
	# Every fruit scene adds itself to the "fruit" group.
	var fruits: Array[Node] = get_tree().get_nodes_in_group("fruit")
	_total = fruits.size()
	for fruit: Node in fruits:
		fruit.connect("collected", _on_fruit_collected)
	_update_score()


func _on_fruit_collected() -> void:
	_collected += 1
	_update_score()


func _update_score() -> void:
	score_label.text = "Fruits: %d / %d" % [_collected, _total]
