class_name Fruit
extends Area2D

## Emitted once, the moment the player touches this fruit.
signal collected

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D

# Guards against a double pickup while the "collected" animation is playing.
var _taken: bool = false


func _ready() -> void:
	animated_sprite.play("apple")
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	# Only the player collects fruit, and only once.
	# (Group check instead of a direct Player type test, so the two scenes stay
	# independent and always parse, whatever order the classes get registered.)
	if _taken or not body.is_in_group("player"):
		return
	_taken = true
	# Stop the pickup area right away so it cannot trigger twice.
	set_deferred("monitoring", false)
	animated_sprite.play("collected")
	animated_sprite.animation_finished.connect(_on_animation_finished)
	collected.emit()


func _on_animation_finished() -> void:
	queue_free()
