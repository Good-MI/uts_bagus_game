class_name Player
extends CharacterBody2D

## Horizontal run speed in pixels/second.
const SPEED := 300.0
## Upward impulse of a jump. Raised to -450 because the sprite is scaled 3x.
const JUMP_VELOCITY := -450.0

# Kept in a @onready var so no get_node() call happens every physics frame.
@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D


func _physics_process(delta: float) -> void:
	# Gravity only while airborne, so the body stays glued to the floor.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Jump is possible ONLY while standing on the ground (no double jump).
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Custom input map: A = left (-1), D = right (+1), nothing = 0.
	var direction: float = Input.get_axis("move_left", "move_right")
	if direction != 0.0:
		velocity.x = direction * SPEED
	else:
		# No horizontal input: brake to a full stop instead of sliding forever.
		velocity.x = move_toward(velocity.x, 0.0, SPEED)

	move_and_slide()

	# Animation is driven from the final state (floor contact + input).
	update_animation(direction)


## Picks the correct animation for this frame.
## direction: -1 = left, 0 = no horizontal input, 1 = right.
func update_animation(direction: float) -> void:
	# The source sprites face right, so left = flip_h. Direction 0 keeps the
	# last facing, so the idle sprite does not snap back to the right.
	if direction != 0.0:
		animated_sprite.flip_h = direction < 0.0

	if not is_on_floor():
		# Rising (or the exact apex) uses "jump", falling uses "fall".
		if velocity.y > 0.0 and animated_sprite.sprite_frames.has_animation("fall"):
			animated_sprite.play("fall")
		else:
			animated_sprite.play("jump")
	elif direction != 0.0:
		animated_sprite.play("run")
	else:
		animated_sprite.play("idle")
