class_name PlayerPhysicsTest
extends Node

# Integration tests for the UTS platformer. Every test instantiates the real
# res://Scenes/main.tscn and drives it with real input events through the
# Input singleton, so these assert the behaviour of the running game, not a
# re-implementation of it.

const MAIN_SCENE := "res://Scenes/main.tscn"
## y of the top face of the ground row (tile row 36).
const GROUND_TOP := 576.0
## Half width of the player's 54x72 collision rectangle.
const BOX_HALF_W := 27.0
## Distance from the player's origin down to the bottom of the collision box.
const BOX_BOTTOM := 48.0
## Left face of the brick wall the player has to be stopped by (tiles x 57..60).
const WALL_LEFT_FACE := 912.0
## Right face of the left world-edge wall (tile x 6, pixels 96..112).
const LEFT_WALL_FACE := 112.0

const ACTIONS := ["move_left", "move_right", "jump"]

var _world: Node = null
var _player: CharacterBody2D = null


# ------------------------------------------------------------------ helpers

func _press(action: String) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = true
	Input.parse_input_event(event)


func _release(action: String) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = false
	Input.parse_input_event(event)


func _clear_world() -> void:
	for action: String in ACTIONS:
		Input.action_release(action)
	if is_instance_valid(_world):
		_world.queue_free()
		_world = null
		_player = null
		await get_tree().physics_frame


## Frees any previous world, then spawns a clean copy of main.tscn and lets the
## player fall the last few pixels onto the ground.
func _fresh_world() -> void:
	await _clear_world()
	_world = (load(MAIN_SCENE) as PackedScene).instantiate()
	add_child(_world)
	for _i in range(10):
		await get_tree().physics_frame
	_player = get_tree().get_first_node_in_group("player") as CharacterBody2D


func _box_right() -> float:
	return _player.global_position.x + BOX_HALF_W


func _box_left() -> float:
	return _player.global_position.x - BOX_HALF_W


func _box_bottom() -> float:
	return _player.global_position.y + BOX_BOTTOM


func _sprite() -> AnimatedSprite2D:
	return _player.get_node("AnimatedSprite2D") as AnimatedSprite2D


# -------------------------------------------------------------------- tests

func test_input_map_uses_custom_physical_keys() -> void:
	for action: String in ACTIONS:
		assert(InputMap.has_action(action), "input action %s is missing" % action)
		var events: Array[InputEvent] = InputMap.action_get_events(action)
		assert(events.size() == 1, "%s should hold exactly one key" % action)
		var key := events[0] as InputEventKey
		assert(key != null, "%s must be bound to a key" % action)
		assert(key.physical_keycode != 0, "%s must use a physical key" % action)
	assert((InputMap.action_get_events("move_left")[0] as InputEventKey).physical_keycode == KEY_A)
	assert((InputMap.action_get_events("move_right")[0] as InputEventKey).physical_keycode == KEY_D)
	assert((InputMap.action_get_events("jump")[0] as InputEventKey).physical_keycode == KEY_W)


func test_player_scene_structure() -> void:
	var player: Node = (load("res://Scenes/player.tscn") as PackedScene).instantiate()
	add_child(player)
	var shape_node := player.get_node("CollisionShape2D") as CollisionShape2D
	assert(shape_node.get_parent() == player, "CollisionShape2D must be a direct child of Player, not of the scaled sprite")
	var rect := shape_node.shape as RectangleShape2D
	assert(rect != null and rect.size == Vector2(54, 72), "collision rectangle must be 54x72")
	assert(shape_node.position == Vector2(0, 12), "collision rectangle must sit at (0, 12)")
	var sprite := player.get_node("AnimatedSprite2D") as AnimatedSprite2D
	assert(sprite.scale == Vector2(3, 3), "the 32x32 sprite must be scaled 3x")
	player.queue_free()


func test_sprite_frames_animations() -> void:
	var player: Node = (load("res://Scenes/player.tscn") as PackedScene).instantiate()
	add_child(player)
	var sprite := player.get_node("AnimatedSprite2D") as AnimatedSprite2D
	var frames: SpriteFrames = sprite.sprite_frames
	var names: PackedStringArray = frames.get_animation_names()
	assert(not names.has("default"), "the default animation must be removed")
	assert(names.has("idle"), "idle animation missing")
	assert(names.has("run"), "run animation missing")
	assert(names.has("jump"), "jump animation missing")
	assert(names.has("fall"), "fall animation missing")
	assert(frames.get_frame_count("idle") == 11, "idle must have 11 frames")
	assert(frames.get_frame_count("run") == 12, "run must have 12 frames")
	assert(frames.get_frame_count("jump") == 1, "jump must have 1 frame")
	assert(is_equal_approx(frames.get_animation_speed("idle"), 15.0), "idle must run at 15 FPS")
	assert(is_equal_approx(frames.get_animation_speed("run"), 20.0), "run must run at 20 FPS")
	assert(frames.get_animation_loop("idle") and frames.get_animation_loop("run") and frames.get_animation_loop("jump"))
	assert(String(sprite.autoplay) == "idle", "idle must be the autoplay animation")
	player.queue_free()


func test_single_player_spawns_on_the_ground() -> void:
	await _fresh_world()
	assert(get_tree().get_nodes_in_group("player").size() == 1, "there must be exactly one player at runtime")
	assert(_player.is_on_floor(), "the player must spawn standing on the ground")
	assert(absf(_box_bottom() - GROUND_TOP) <= 1.0, "the player's feet must rest on the ground top (bottom=%f)" % _box_bottom())


func test_stands_still_without_sinking_or_jitter() -> void:
	await _fresh_world()
	var start_y: float = _player.global_position.y
	for _i in range(90):
		await get_tree().physics_frame
		assert(absf(_player.global_position.y - start_y) < 1.0, "the player must not sink or bounce while standing")
	assert(is_zero_approx(_player.velocity.y), "vertical velocity must settle to zero on the ground")
	assert(_player.is_on_floor(), "the player must stay on the floor")


func test_jump_only_from_the_ground() -> void:
	await _fresh_world()
	var start_y: float = _player.global_position.y
	_press("jump")
	await get_tree().physics_frame
	await get_tree().physics_frame
	_release("jump")
	assert(_player.velocity.y < 0.0, "W on the ground must launch the player upward")

	# Fall past the apex so the next press lands in mid-air on the way down.
	var peak: float = _player.global_position.y
	for _i in range(90):
		await get_tree().physics_frame
		peak = minf(peak, _player.global_position.y)
		if not _player.is_on_floor() and _player.velocity.y > 10.0:
			break
	assert(peak < start_y - 40.0, "the jump must really leave the ground (peak %f)" % peak)
	assert(not _player.is_on_floor(), "the player should still be airborne for the mid-air test")

	_press("jump")
	await get_tree().physics_frame
	await get_tree().physics_frame
	_release("jump")
	assert(_player.velocity.y > -20.0, "W in mid-air must NOT relaunch the player (velocity.y=%f)" % _player.velocity.y)
	var later_peak: float = _player.global_position.y
	for _i in range(60):
		await get_tree().physics_frame
		later_peak = minf(later_peak, _player.global_position.y)
	assert(later_peak >= peak - 1.0, "a mid-air W must not raise the player above the first jump's peak")


func test_left_right_flip_and_idle() -> void:
	await _fresh_world()
	var sprite := _sprite()
	var start_x: float = _player.global_position.x

	# D -> right, sprite unchanged (source art faces right).
	_press("move_right")
	for _i in range(12):
		await get_tree().physics_frame
	assert(_player.velocity.x > 0.0, "D must move the player right")
	assert(_player.global_position.x > start_x, "the player must actually travel right")
	assert(not sprite.flip_h, "facing right must not flip the sprite")
	assert(String(sprite.animation) == "run", "moving on the ground must play run")

	# Release -> brake to a stop and go back to idle facing right.
	_release("move_right")
	for _i in range(30):
		await get_tree().physics_frame
	assert(is_zero_approx(_player.velocity.x), "releasing the key must stop the player")
	assert(String(sprite.animation) == "idle", "standing still must play idle")
	assert(not sprite.flip_h, "idle must keep the last facing (right)")

	# A -> left, sprite flipped.
	var mid_x: float = _player.global_position.x
	_press("move_left")
	for _i in range(12):
		await get_tree().physics_frame
	assert(_player.velocity.x < 0.0, "A must move the player left")
	assert(_player.global_position.x < mid_x, "the player must actually travel left")
	assert(sprite.flip_h, "facing left must set flip_h")
	assert(String(sprite.animation) == "run", "moving on the ground must play run")

	_release("move_left")
	for _i in range(30):
		await get_tree().physics_frame
	assert(String(sprite.animation) == "idle", "standing still must play idle")
	assert(sprite.flip_h, "idle must keep the last facing (left)")


func test_jump_and_fall_animations_play_in_the_air() -> void:
	await _fresh_world()
	var sprite := _sprite()
	_press("jump")
	await get_tree().physics_frame
	await get_tree().physics_frame
	_release("jump")
	await get_tree().physics_frame
	assert(not _player.is_on_floor(), "the player must be airborne")
	assert(String(sprite.animation) == "jump", "rising must play jump (got %s)" % sprite.animation)
	for _i in range(90):
		await get_tree().physics_frame
		if _player.velocity.y > 10.0:
			break
	assert(String(sprite.animation) == "fall", "falling must play fall (got %s)" % sprite.animation)


func test_right_wall_stops_the_player() -> void:
	await _fresh_world()
	_press("move_right")
	for _i in range(240):
		await get_tree().physics_frame
	assert(absf(_box_right() - WALL_LEFT_FACE) <= 1.5, "holding D must stop the player's box at the wall face 912 (got %f)" % _box_right())
	assert(_player.is_on_wall(), "the player must be reported as touching the wall")
	assert(_player.global_position.x < WALL_LEFT_FACE, "the player must not pass into the wall")
	_release("move_right")


func test_left_wall_stops_the_player() -> void:
	await _fresh_world()
	_press("move_left")
	for _i in range(180):
		await get_tree().physics_frame
	assert(absf(_box_left() - LEFT_WALL_FACE) <= 1.5, "holding A must stop the player's box at the left wall face 112 (got %f)" % _box_left())
	assert(_player.global_position.x > 96.0, "the player must not pass through the left edge wall")
	_release("move_left")


func test_default_texture_filter_is_nearest() -> void:
	await _fresh_world()
	var setting: float = float(ProjectSettings.get_setting("rendering/textures/canvas_textures/default_texture_filter", 1))
	assert(is_zero_approx(setting), "the project must default to Nearest (0), got %s" % setting)
	assert(_world.get_viewport().canvas_item_default_texture_filter == 0, "the live viewport must resolve to Nearest filtering")


func test_ground_fruit_is_collected_on_contact() -> void:
	await _fresh_world()
	var label := _world.get_node("HUD/ScoreLabel") as Label
	assert(label.text == "Fruits: 0 / 3", "HUD must start at 0 of 3 (got %s)" % label.text)
	_press("move_right")
	for _i in range(150):
		await get_tree().physics_frame
	_release("move_right")
	assert(label.text == "Fruits: 1 / 3", "walking through the ground fruit must collect exactly one (got %s)" % label.text)


func test_floating_fruits_are_not_collected_by_walking_under_them() -> void:
	await _fresh_world()
	var label := _world.get_node("HUD/ScoreLabel") as Label
	_press("move_left")
	for _i in range(40):
		await get_tree().physics_frame
	_release("move_left")
	_press("move_right")
	for _i in range(150):
		await get_tree().physics_frame
	_release("move_right")
	# Only the ground fruit at (720, 520) may be reached without jumping.
	assert(label.text == "Fruits: 1 / 3", "the two airborne fruits must need a jump (got %s)" % label.text)
